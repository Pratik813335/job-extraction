export { default as ModernLoginView } from './modern-login-view';
export { default as ModernVerifyView } from './modern-verify-view';
export { default as ModernRegisterView } from './modern-register-view';
export { default as ModernNewPasswordView } from './modern-new-password-view';
export { default as ModernForgotPasswordView } from './modern-forgot-password-view';
