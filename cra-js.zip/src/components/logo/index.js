export { default } from './logo';
