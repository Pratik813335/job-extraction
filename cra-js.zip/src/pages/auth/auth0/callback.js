// ----------------------------------------------------------------------

export default function CallbackPage() {
  console.info('CallbackPage');
  return null;
}
